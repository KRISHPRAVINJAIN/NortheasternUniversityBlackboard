package com.me.neubb.pojo;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name = "Assignment")
@NamedQueries ({
   @NamedQuery(name = "findAssignmentById", query = "FROM Assignment where id = :id")
    })
public class Assignment {

	
	
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Id", unique = true, nullable = false)
    private int id;
	
	@Transient
	 private MultipartFile File;
	 
	 @Column(name="NAME")
	 private String filename;
	 
	
	@ManyToMany(targetEntity=User.class,mappedBy="assignment")
	private Set user_table;

	
	
	
	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public MultipartFile getFile() {
		return File;
	}

	public void setFile(MultipartFile file) {
		File = file;
	}

	public Set getUser_table() {
		return user_table;
	}

	public void setUser_table(Set user_table) {
		this.user_table = user_table;
	}
	
	
}
