package com.me.neubb.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.me.neubb.pojo.Work;



public class WorkValidator  implements Validator {

    @Override
    public boolean supports(Class<?> type) {
         return type.isAssignableFrom(Work.class);
    }

    @Override
    public void validate(Object o, Errors errors) {
          ValidationUtils.rejectIfEmptyOrWhitespace(errors, "company", "empty-title", "cannot be blank");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "employer", "empty-actor", "cannot be blank");
         ValidationUtils.rejectIfEmptyOrWhitespace(errors, "duration", "empty-actress", " cannot be blank");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "payment", "empty-genre", "cannot be blank");
         ValidationUtils.rejectIfEmptyOrWhitespace(errors, "type1", "empty-year", " cannot be blank");
         
    }

}
