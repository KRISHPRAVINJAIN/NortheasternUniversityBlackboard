package com.me.neubb.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.me.neubb.pojo.Jobs;

public class XlsView extends AbstractExcelView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model, 
			HSSFWorkbook workbook,
			HttpServletRequest request, 
			HttpServletResponse response) 
				throws Exception {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		List<Jobs> orders = (List<Jobs>) session.getAttribute("orders");
		 CellStyle style = workbook.createCellStyle();
         Font font = workbook.createFont();
         font.setFontName("Arial");
         font.setColor(HSSFColor.WHITE.index);
         style.setFont(font);
         
         
         // create a new Excel sheet
         HSSFSheet sheet = workbook.createSheet("JobSheet");
         sheet.setDefaultColumnWidth(30);
         // create header row
         HSSFRow header = sheet.createRow(0);
         
         header.createCell(0).setCellValue("JobID");
         header.getCell(0).setCellStyle(style);
         
         header.createCell(1).setCellValue("JobTitle");
         header.getCell(1).setCellStyle(style);
     
     	 header.createCell(2).setCellValue("JobRole");
         header.getCell(2).setCellStyle(style);
         
         header.createCell(3).setCellValue("JobLocation");
         header.getCell(3).setCellStyle(style);
         
         header.createCell(4).setCellValue("JobVacancy");
         header.getCell(4).setCellStyle(style);
         
         header.createCell(5).setCellValue("JobWebsite");
         header.getCell(5).setCellStyle(style);
       
       
      int rowNum = 1;
      for(Jobs salesorder:orders){
          HSSFRow aRow = sheet.createRow(rowNum++);
             aRow.createCell(0).setCellValue(salesorder.getJobID());
             aRow.createCell(1).setCellValue(salesorder.getJobTitle());
             aRow.createCell(2).setCellValue(salesorder.getJobRole());
             aRow.createCell(3).setCellValue(salesorder.getJobLocation());
             aRow.createCell(4).setCellValue(salesorder.getJobVacancy());
             aRow.createCell(5).setCellValue(salesorder.getJobWebsite());
      
            
     
      }
     
	}

}