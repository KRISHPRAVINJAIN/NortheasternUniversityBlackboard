package com.me.neubb.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.me.neubb.dao.WorkDAO;
import com.me.neubb.pojo.Course;
import com.me.neubb.pojo.Work;
import com.me.neubb.validator.WorkValidator;

@Controller
@RequestMapping(value="/user/work/*")
public class WorkController {
	
	@Autowired
	@Qualifier("workDao")
	WorkDAO workDao;
	
	@Autowired
	@Qualifier("workValidator")
	WorkValidator workValidator;
	
	@InitBinder
	private void initBinder(WebDataBinder binder) {
	binder.setValidator(workValidator);	
	}
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView initializeForm(HttpServletRequest request) throws Exception {		
				ModelAndView mv = new ModelAndView();
				mv.setViewName("work-form");
				mv.addObject("work", new Work());
				return mv;
			
	}
	
	@RequestMapping(value = "/user/work/add", method = RequestMethod.POST)
    public ModelAndView addMovie(HttpServletRequest request, @ModelAttribute("work") Work work, BindingResult result) throws Exception {
        
        workValidator.validate(work, result);
         
        if (result.hasErrors()) {
            return new ModelAndView("work-form", "work", work);
        }

        try {                
        	System.out.println("calling create");
            work = workDao.create(work);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return new ModelAndView("error", "errorMessage", "error while creating work");
        }
        return new ModelAndView("work-success", "work", work);
        
    }
	

}
