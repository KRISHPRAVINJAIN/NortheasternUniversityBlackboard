package com.me.neubb.pojo;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "Course")
@NamedQueries ({
   @NamedQuery(name = "findCourseById", query = "FROM Course where id = :id")
    })
public class Course {
	
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID", unique = true, nullable = false)
    private int id;
	
	@Column(name="TITLE")
    private String title;
	@Column(name="PROFESSOR")
    private String professor;
	@Column(name="COLLEGE")
    private String college;
	@Column(name="CREDITS")
    private String credits;
	@Column(name="TYPE")
    private String type;
  
	@ManyToMany(targetEntity=User.class,mappedBy="course")
	private Set user_table;
	
    public Course(){
    	
    }
    
    public Set getUser_table() {
		return user_table;
	}



	public void setUser_table(Set user_table) {
		this.user_table = user_table;
	}



	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getProfessor() {
		return professor;
	}


	public void setProfessor(String professor) {
		this.professor = professor;
	}


	public String getCollege() {
		return college;
	}


	public void setCollege(String college) {
		this.college = college;
	}


	public String getCredits() {
		return credits;
	}


	public void setCredits(String credits) {
		this.credits = credits;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}
    
    
    
    
}