package com.me.neubb.pojo;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.JoinColumn;

@Entity
@Table(name = "user_table")
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
    private long id;

	@Column(name = "userEmail")
	private String userEmail;

	@Column(name = "password")
	private String password;
	
	@Column(name = "status")
	private int status;
	
	@Column(name = "role")
	private String role;
	
	@ManyToMany(targetEntity=Course.class,cascade=CascadeType.ALL)
	@JoinTable(name="user_table_course",joinColumns=@JoinColumn(name="user_table_id_fk",referencedColumnName="id"),inverseJoinColumns=@JoinColumn(name="course_id_fk",referencedColumnName="ID"))
	private Set course;
	
	@ManyToMany(targetEntity=Assignment.class,cascade=CascadeType.ALL)
	@JoinTable(name="user_table_assignment",joinColumns=@JoinColumn(name="user_table_id_fk1",referencedColumnName="id"),inverseJoinColumns=@JoinColumn(name="assignment_id_fk",referencedColumnName="Id"))
	private Set assignment ;
	
	public User() {
		
	
	}
	
	
	
	

	public String getRole() {
		return role;
	}





	public void setRole(String role) {
		this.role = role;
	}





	public Set getAssignment() {
		return assignment;
	}



	public void setAssignment(Set assignment) {
		this.assignment = assignment;
	}



	public long getId() {
		return id;
	}



	public void setId(long id) {
		this.id = id;
	}



	public Set getCourse() {
		return course;
	}



	public void setCourse(Set course) {
		this.course = course;
	}



	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
	
	
	
}