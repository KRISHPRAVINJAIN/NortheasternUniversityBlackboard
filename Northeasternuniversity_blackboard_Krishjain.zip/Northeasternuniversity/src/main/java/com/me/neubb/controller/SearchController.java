package com.me.neubb.controller;



import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.me.neubb.dao.CourseDAO;
import com.me.neubb.pojo.*;
@Controller
@RequestMapping("/user/search/*")
public class SearchController {

	@Autowired
	@Qualifier("courseDao")
	CourseDAO courseDao;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView initializeForm(HttpServletRequest request) throws Exception {		
				ModelAndView mv = new ModelAndView();
				mv.setViewName("search-form");
				return mv;
			
	}
	
	@RequestMapping(value = "/user/search/searchcourses", method = RequestMethod.POST)
    public ModelAndView searchCourse(HttpServletRequest request) throws Exception {
        
		String searchType=request.getParameter("selection");
		String query=request.getParameter("query");
		HttpSession session = request.getSession();
		List<Course> courses;
		System.out.println(searchType);
		System.out.println(query);
		
        try {       
        	courses=(List<Course>) courseDao.getCoursesByQuery(searchType,query);
            if(!courses.isEmpty())
            {
            session.setAttribute("courses",courses);
            System.out.println(courses);
            }
        	
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return new ModelAndView("course-error", "errorMessage", "error while searching course");
        }
        
        return new ModelAndView("success-search", "courses", courses);
        }
}
