package com.me.neubb.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.me.neubb.dao.CourseDAO;
import com.me.neubb.dao.DAO;
import com.me.neubb.dao.UserDAO;
import com.me.neubb.pojo.Course;
import com.me.neubb.pojo.User;
import com.me.neubb.validator.CourseValidator;

@Controller
@RequestMapping(value="/user/course/*")
public class CourseController {

	@Autowired
	@Qualifier("courseDao")
	CourseDAO courseDao;
	
	
	@Autowired
	@Qualifier("courseValidator")
	CourseValidator courseValidator;

	
	
	@InitBinder
	private void initBinder(WebDataBinder binder) {
		
		binder.setValidator(courseValidator);
	}
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView initializeForm(HttpServletRequest request) throws Exception {		
				ModelAndView mv = new ModelAndView();
				mv.setViewName("course-form");
				mv.addObject("course", new Course());
				return mv;
			
	}
	
		
	@RequestMapping(value = "/user/course/add", method = RequestMethod.POST)
    public ModelAndView addMovie(HttpServletRequest request, @ModelAttribute("course") Course course, BindingResult result) throws Exception {
        
        courseValidator.validate(course, result);
         
        if (result.hasErrors()) {
            return new ModelAndView("course-form", "course", course);
        }

        try {                
        	System.out.println("calling create");
            course = courseDao.create(course);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return new ModelAndView("course-error", "errorMessage", "error while creating course");
        }
        return new ModelAndView("course-success", "course", course);
        
    }
	
	@RequestMapping(value="/user/course/save", method= RequestMethod.POST)
	public String saveCourse(HttpServletRequest request
		)throws Exception{
		HttpSession session1 = request.getSession();
		System.out.println("save function");
		UserDAO userDao = new UserDAO();
		String[] courseToAdd =  request.getParameterValues("addselected");
		Set<Course> courses = new HashSet<Course>();
        for (String str : courseToAdd) {
            int id = Integer.parseInt(str);
            System.out.print(id);
            
           Session session = DAO.getSession();
           Query query = session.getNamedQuery("findCourseById").setInteger("id",id);
           query.setMaxResults(1);
           Course course = (Course) query.uniqueResult();
           courses.add(course);
        }
        
        System.out.print(courses.size());
        String email = (String)session1.getAttribute("username");
        System.out.print(email);
        Set<Course> mycourse = new HashSet<Course>();
        mycourse = userDao.updateUser(email, courses);
        session1.setAttribute("mycourses", mycourse);
		return "mycourse-view";
		
	}
	
	 @RequestMapping(value = "/user/course/save", method = RequestMethod.GET)
		public String send(HttpServletRequest request) {
	     return "mycourse-view";	
	    	
	    }
	
	@RequestMapping(value="/user/course/delete", method= RequestMethod.POST)
	public String deleteCourse(HttpServletRequest request
		)throws Exception{
		HttpSession session1 = request.getSession();
		
		UserDAO userDao = new UserDAO();
		String[] courseTodelete =  request.getParameterValues("delete");
		Set<Course> courses = new HashSet<Course>();
		Set<Course> mycourse = new HashSet<Course>();
        for (String str : courseTodelete) {
            int id = Integer.parseInt(str);
            System.out.print(id);
            
           Session session = DAO.getSession();
           Query query = session.getNamedQuery("findCourseById").setInteger("id",id);
           query.setMaxResults(1);
           Course course = (Course) query.uniqueResult();
           courses.add(course);
        }
        
        System.out.print(courses.size());
        String email = (String)session1.getAttribute("username");
        System.out.print(email);
        mycourse = userDao.updateUser1(email, courses);
        session1.setAttribute("mycourses", mycourse);
		return "mycourse-view";
		
	}
	
	
}

