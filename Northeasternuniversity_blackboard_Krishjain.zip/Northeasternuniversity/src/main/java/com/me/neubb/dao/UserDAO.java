package com.me.neubb.dao;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.query.Query;

import com.me.neubb.pojo.Course;
import com.me.neubb.pojo.User;

public class UserDAO extends DAO {

	public UserDAO() {
	}

	public User get(String userEmail, String password) throws Exception {
		try {
			begin();
			Query q = getSession().createQuery("from User where userEmail = :useremail and password = :password");
			q.setString("useremail", userEmail);
			q.setString("password", password);			
			User user = (User) q.uniqueResult();
			return user;
		} catch (HibernateException e) {
			rollback();
			throw new Exception("Could not get user " + userEmail, e);
		}
	}
	
	public User get(String userEmail){
		try {
			begin();
			Query q = getSession().createQuery("from User where userEmail = :useremail");
			q.setString("useremail", userEmail);
			User user = (User) q.uniqueResult();
			return user;
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
			return null;
		
	}
	

	public User register(User u) throws Exception {
		try {
			begin();
			System.out.println("inside DAO");
			getSession().save(u);
			commit();
			return u;

		} catch (HibernateException e) {
			rollback();
			throw new Exception("Exception while creating user: " + e.getMessage());
		}
	}
	
	public boolean updateUser(String email) throws Exception {
        try {
            begin();
            System.out.println("inside DAO");
            Query q = getSession().createQuery("from User where userEmail = :useremail");
            q.setString("useremail", email);
            User user = (User) q.uniqueResult();
            if(user!=null){
                user.setStatus(1);
                getSession().update(user);
                commit();
                return true;
            }else{
                return false;
            }

        } catch (HibernateException e) {
            rollback();
            throw new Exception("Exception while creating user: " + e.getMessage());
        }
    
    }
	
	public Set<Course> updateUser(String email, Set<Course> courses) throws Exception {
        try {
            begin();
            System.out.println("inside DAO");
            Query q = getSession().createQuery("from User where userEmail = :useremail");
            q.setString("useremail", email);
            User user = (User) q.uniqueResult();
            System.out.println(user.getUserEmail());
            System.out.println(user.getCourse().size());
            
            HashSet<Course> courseset = new HashSet<Course>();
            
            for(Course course: courses) {
            	courseset.add(course);
            }
            System.out.println(courseset.size());
            
            Set<Course> existingcourses = user.getCourse();
            
            for(Course course: existingcourses) {
            	courseset.add(course);
            }
            
            System.out.println(user.getCourse().size());
            
            user.setCourse(courseset);
            if(user!=null){
                user.setStatus(1);
                getSession().update(user);
                commit();
                return courseset;
            }else{
                return null;
            }

        } catch (HibernateException e) {
            rollback();
            throw new Exception("Exception while creating user: " + e.getMessage());
        }
    
    }
	
	public Set<Course> updateUser1(String email, Set<Course> courses) throws Exception {
        try {
            begin();
            System.out.println("inside DAO");
            Query q = getSession().createQuery("from User where userEmail = :useremail");
            q.setString("useremail", email);
            User user = (User) q.uniqueResult();
            System.out.println(user.getUserEmail());
            
            Set<Course> courseset =  user.getCourse();

        	System.out.println("user current course");
            for(Course c: courseset) {
            	
            	System.out.println(c.getTitle());
            }

        	System.out.println("to delete");
			for(Course c: courses) {
			            	
			            	System.out.println(c.getTitle());
			            }

            for(Course course: courses) {
            	if(courseset.contains(course) ){
            		System.out.println(course.getTitle());
            		courseset.remove(course);
            	}
            }
            
            user.setCourse(courseset);
            if(user!=null){
                user.setStatus(1);
                getSession().update(user);
                commit();
                return courseset;
            }else{
                return null;
            }

        } catch (HibernateException e) {
            rollback();
            throw new Exception("Exception while creating user: " + e.getMessage());
        }
    
    }

	
}