package com.me.neubb.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.me.neubb.dao.JobDAO;
import com.me.neubb.pojo.Jobs;

@Controller
@RequestMapping(value="/user/job/*")
public class CSVController {

	@Autowired
	@Qualifier("jobDao")
	JobDAO jobDao;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	   public ModelAndView initializeForm(HttpServletRequest request) throws Exception {        
	               ModelAndView mv = new ModelAndView();
	               mv.setViewName("jobs-view");
	               return mv;
	           
	   }
	
	@RequestMapping(value = "/user/job/upload" , method = RequestMethod.POST) 
    public ModelAndView UploadData(HttpServletRequest request, @ModelAttribute("filename") String filename, BindingResult result) throws Exception {
        
        HttpSession session = request.getSession();
        
       if(!filename.equals("")){
       int page = Integer.parseInt(request.getParameter("page"));
       
       int totalcount = jobDao.getData(filename);
       session.setAttribute("totalcount", totalcount);
       
       List<Jobs> orders = new ArrayList<Jobs>();
       orders = jobDao.readData(filename, page);
       System.out.println(orders.size());  
       session.setAttribute("orders", orders);
       ModelAndView mv = new ModelAndView();  
       mv.getModelMap().addAttribute("orders", orders);
       mv.setViewName("jobs-view");

       return mv;
       
       }
       
       else{
           session.setAttribute("message", "Please enter a valid filename");
           return new ModelAndView("jobs-view","message","Please enter a valid filename");
           
       }
    }
	
	@RequestMapping(value = "/user/job/page", method = RequestMethod.GET)
	public ModelAndView UploadPaginatedData(HttpServletRequest request) throws Exception {
		 HttpSession session = request.getSession();
		 int page = Integer.parseInt(request.getParameter("page"));
		 
		 	List<Jobs> orders = new ArrayList<Jobs>();
	        orders = jobDao.readData("JobSheet", page);
	        
	        session.setAttribute("orders", orders);
	        
	        
	        ModelAndView mv = new ModelAndView("jobs-view","orders",orders);

	        return mv;
	        
	        
	}
	
	@RequestMapping(value = "/user/job/add" , method = RequestMethod.POST) 
	public ModelAndView AddData(HttpServletRequest request) throws Exception {
		
		HttpSession session = request.getSession();
		List<Jobs> orders =  (List<Jobs>) session.getAttribute("orders");

        jobDao.addData(orders);
        session.setAttribute("rowsAffected", orders.size());
        ModelAndView mv = new ModelAndView("jobs-view");
        return mv;
		
        
	}  
	
	@RequestMapping(value = "/user/job/save" , method = RequestMethod.POST) 
	
	 public ModelAndView getExcel(HttpServletRequest request) {
	       HttpSession session = request.getSession();
	      ArrayList<Jobs> orders = new ArrayList<Jobs>();
	       orders = (ArrayList<Jobs>) session.getAttribute("data");
	       ModelAndView mv = new ModelAndView();
	       mv.getModelMap().addAttribute("orderData",orders);
	       mv.setView(new XlsView());
	       return mv;
	    }
	
	
	
}
