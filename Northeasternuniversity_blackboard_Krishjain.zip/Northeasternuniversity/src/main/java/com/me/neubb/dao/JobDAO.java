package com.me.neubb.dao;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.relique.jdbc.csv.CsvConnection;
import org.relique.jdbc.csv.CsvPreparedStatement;
import org.relique.jdbc.csv.CsvResultSet;


import com.me.neubb.pojo.Jobs;

public class JobDAO extends DAO{
	
	public int getData(String filename) throws ClassNotFoundException, SQLException {
        Class.forName("org.relique.jdbc.csv.CsvDriver");
       CsvConnection conn=(CsvConnection) DriverManager.getConnection("jdbc:relique:csv:");
       CsvPreparedStatement stmt;
       
       stmt = (CsvPreparedStatement) conn.prepareStatement("select 1 FROM "+filename);
       CsvResultSet results =(CsvResultSet) stmt.executeQuery();
       
       int size =0;
       while(results.next()){
           size = size + 1;
           
       }
//        System.out.println("size:" + size);
        return size;
       
    }
	
	 public List<Jobs> readData(String filename, int page) throws ClassNotFoundException, SQLException {
	        
	        
	        Class.forName("org.relique.jdbc.csv.CsvDriver");
	       CsvConnection conn=(CsvConnection) DriverManager.getConnection("jdbc:relique:csv:");
	       CsvPreparedStatement stmt;
	       
	           int start = (page -1)*100;
//	            System.out.println("start: " + start);
	           stmt = (CsvPreparedStatement) conn.prepareStatement("select * FROM "+filename+ " LIMIT 100 OFFSET " + start);
	       System.out.println(filename);
	       CsvResultSet results =(CsvResultSet) stmt.executeQuery();
	       List<Jobs> orders = new ArrayList<Jobs>();
	    //   orders=new ArrayList<Jobs>();
	       
	       try{
	           
	           
	           while(results.next()){
	        	
	           Jobs order = Jobs.class.newInstance();
	           
	           order.setJobID(results.getString("JobID"));
	           order.setJobTitle(results.getString("JobTitle"));
	           order.setJobRole(results.getString("JobRole"));
	           order.setJobLocation(results.getString("JobLocation"));
	           order.setJobVacancy(results.getString("JobVacancy"));
	           order.setJobWebsite(results.getString("JobWebsite"));
	         
	           orders.add(order);
	           
	           }
	           System.out.println(orders);
	           return orders;
	           }
	           catch(Exception e){
	               e.printStackTrace();
	           }
	          return null;
	       }
	 
	 public void addData(List<Jobs> orders) throws Exception {
	    	
	   	 try {
	            
	            begin();
	            System.out.println("before loop");
	            for(Jobs order : orders) {
	             System.out.println("Job id: " +order.getJobID());	 
	             getSession().save(order);
	            }
	            commit();
	            
	            
	        } catch (HibernateException e) {
	        	System.out.println(e.toString());
	            rollback();
	            throw new Exception("Exception while creating job: " + e.getMessage());
	        }
	   	    

	   }

}
