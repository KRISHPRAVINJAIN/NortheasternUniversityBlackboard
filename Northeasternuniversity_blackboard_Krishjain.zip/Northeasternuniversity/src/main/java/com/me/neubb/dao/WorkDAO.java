package com.me.neubb.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.query.Query;

import com.me.neubb.pojo.Work;



public class WorkDAO extends DAO{

	public List<Work> getWorkByQuery(String searchType,String query) throws Exception {
	       try {
	          begin();
	           Query q=getSession().createQuery("from Work where " +searchType + " like :query")
	     
	           .setString("query", "%" +query+ "%");
	           
	           List<Work> works = q.list();
	           commit();
	           return works;
	    	   
	           
	       } catch (HibernateException e) {
	           rollback();
	           throw new Exception("Could not obtain the movie " + searchType + " " + e.getMessage());
	       }
	   }

	   public List<Work> list() throws Exception {
	       try {
	           begin();
	           Query q = getSession().createQuery("from WORK");
	           List<Work> list = q.list();
	           commit();
	           return list;
	       } catch (HibernateException e) {
	           rollback();
	           throw new Exception("Could not list the movies", e);
	       }
	   }

	   public Work create(Work work) throws Exception {
	       try {
	    	  
	           begin();
	           getSession().save(work);
	           
	           commit();
	           return work;
	       } catch (HibernateException e) {
	           rollback();
	           //throw new AdException("Could not create the category", e);
	           throw new Exception("Exception while creating movie: " + e.getMessage());
	       }
	   }

	   public void update(Work work) throws Exception {
	       try {
	           begin();
	           getSession().update(work);
	           commit();
	       } catch (HibernateException e) {
	           rollback();
	           throw new Exception("Could not save the movie", e);
	       }
	   }

	   public void delete(Work work) throws Exception {
	       try {
	           begin();
	           getSession().delete(work);
	           commit();
	       } catch (HibernateException e) {
	           rollback();
	           throw new Exception("Could not delete the category", e);
	       }
	   }
	   
	
}
