package com.me.neubb.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.query.Query;
import com.me.neubb.pojo.Course;
public class CourseDAO extends DAO {

	public List<Course> getCoursesByQuery(String searchType,String query) throws Exception {
	       try {
	          begin();
	           Query q=getSession().createQuery("from Course where " +searchType + " like :query")
	     
	           .setString("query", "%" +query+ "%");
	           
	           List<Course> courses = q.list();
	           commit();
	           return courses;
	    	   
	           
	       } catch (HibernateException e) {
	           rollback();
	           throw new Exception("Could not obtain the course " + searchType + " " + e.getMessage());
	       }
	   }

	   public List<Course> list() throws Exception {
	       try {
	           begin();
	           Query q = getSession().createQuery("from COURSE");
	           List<Course> list = q.list();
	           commit();
	           return list;
	       } catch (HibernateException e) {
	           rollback();
	           throw new Exception("Could not list the courses", e);
	       }
	   }

	   public Course create(Course course) throws Exception {
	       try {
	    	  
	           begin();
	           getSession().save(course);
	           
	           commit();
	           return course;
	       } catch (HibernateException e) {
	           rollback();
	           //throw new AdException("Could not create the category", e);
	           throw new Exception("Exception while creating course: " + e.getMessage());
	       }
	   }

	   public void update(Course course) throws Exception {
	       try {
	           begin();
	           getSession().update(course);
	           commit();
	       } catch (HibernateException e) {
	           rollback();
	           throw new Exception("Could not save the course", e);
	       }
	   }

	   public void delete(Course course) throws Exception {
	       try {
	           begin();
	           getSession().delete(course);
	           commit();
	       } catch (HibernateException e) {
	           rollback();
	           throw new Exception("Could not delete the category", e);
	       }
	   }
	   

}
