package com.me.neubb.validator;


import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.me.neubb.pojo.Course;
public class CourseValidator implements Validator {

    @Override
    public boolean supports(Class<?> type) {
         return type.isAssignableFrom(Course.class);
    }

    @Override
    public void validate(Object o, Errors errors) {
          ValidationUtils.rejectIfEmptyOrWhitespace(errors, "title", "empty-title", "title cannot be blank");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "professor", "empty-professor", "professor cannot be blank");
         ValidationUtils.rejectIfEmptyOrWhitespace(errors, "college", "empty-college", "college cannot be blank");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "credits", "empty-credits", "credits cannot be blank");
         ValidationUtils.rejectIfEmptyOrWhitespace(errors, "type", "empty-type", "type cannot be blank");
         
    }

}