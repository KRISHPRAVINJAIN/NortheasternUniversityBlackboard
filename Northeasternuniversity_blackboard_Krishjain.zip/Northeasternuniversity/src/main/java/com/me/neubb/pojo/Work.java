package com.me.neubb.pojo;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Work")
public class Work {
	
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID1", unique = true, nullable = false)
    private int id1;
	
	@Column(name="COMPANY")
    private String company;
	@Column(name="EMPLOYER")
    private String employer;
	@Column(name="DURATION")
    private String duration;
	@Column(name="PAYMENT")
    private String payment;
	@Column(name="TYPE1")
    private String type1;
  
	
	
    public Work(){
    	
    }

	public int getId1() {
		return id1;
	}

	public void setId1(int id1) {
		this.id1 = id1;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getEmployer() {
		return employer;
	}

	public void setEmployer(String employer) {
		this.employer = employer;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getPayment() {
		return payment;
	}

	public void setPayment(String payment) {
		this.payment = payment;
	}

	public String getType1() {
		return type1;
	}

	public void setType1(String type1) {
		this.type1 = type1;
	}

	
    

}
