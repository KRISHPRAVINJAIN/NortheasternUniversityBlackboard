package com.me.neubb.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.me.neubb.dao.WorkDAO;
import com.me.neubb.pojo.Course;
import com.me.neubb.pojo.Work;

@Controller
@RequestMapping("/user/worksearch/*")
public class WorkSearchController {
	
	@Autowired
	@Qualifier("workDao")
	WorkDAO workDao;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView initializeForm(HttpServletRequest request) throws Exception {		
				ModelAndView mv = new ModelAndView();
				mv.setViewName("worksearch-form");
				return mv;
			
	}
	
	@RequestMapping(value = "/user/worksearch/searchworks", method = RequestMethod.POST)
    public ModelAndView searchCourse(HttpServletRequest request) throws Exception {
        
		String searchType=request.getParameter("selection");
		String query=request.getParameter("query");
		HttpSession session = request.getSession();
		List<Work> works;
		System.out.println(searchType);
		System.out.println(query);
		
        try {       
        	works=(List<Work>) workDao.getWorkByQuery(searchType,query);
            if(!works.isEmpty())
            {
            session.setAttribute("works",works);
            System.out.println(works);
            }
        	
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return new ModelAndView("error", "errorMessage", "error while searching work");
        }
        
        return new ModelAndView("success-worksearch", "works", works);
        }

}
