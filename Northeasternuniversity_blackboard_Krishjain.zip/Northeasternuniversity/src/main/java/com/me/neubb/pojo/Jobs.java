package com.me.neubb.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Jobs {

	@Id
	@Column(name="JobID", unique=true, nullable=false )
	private String jobID;
	
	@Column(name="JobTitle")
	private String jobTitle;
	
	@Column(name="JobRole")
	private String jobRole;
	
	@Column(name="JobLocation")
	private String jobLocation;
	
	@Column(name="JobVacancy")
	private String jobVacancy;
	
	@Column(name="JobWebsite")
	private String jobWebsite;

	public String getJobID() {
		return jobID;
	}

	public void setJobID(String jobID) {
		this.jobID = jobID;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getJobRole() {
		return jobRole;
	}

	public void setJobRole(String jobRole) {
		this.jobRole = jobRole;
	}

	public String getJobLocation() {
		return jobLocation;
	}

	public void setJobLocation(String jobLocation) {
		this.jobLocation = jobLocation;
	}

	public String getJobVacancy() {
		return jobVacancy;
	}

	public void setJobVacancy(String jobVacancy) {
		this.jobVacancy = jobVacancy;
	}

	public String getJobWebsite() {
		return jobWebsite;
	}

	public void setJobWebsite(String jobWebsite) {
		this.jobWebsite = jobWebsite;
	}
	
	
	
	
}
