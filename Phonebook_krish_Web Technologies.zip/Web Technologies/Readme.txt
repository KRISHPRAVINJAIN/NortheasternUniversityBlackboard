
Steps to run :

1. Download Node and NPM using the following link: https://nodejs.org/en/download/

2. Make sure if the NPM is running.

3. Open the commandline in the same directory and write 'npm install'. 

4. Once it's done, type in command 'node index.js' and you can run the app on localhost at port 8080. Type 'localhost:8080' in the browser and you are good to go.


Regards
KRISH PRAVIN JAIN
NUID: 001881885

